package mario.android.mlitebaseultimaversao.activity;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;
import java.util.ArrayList;
import java.util.Arrays;

import mario.android.mlitebaseultimaversao.R;
import mario.android.mlitebaseultimaversao.db.MLiteDatabase;
import mario.android.mlitebaseultimaversao.pojo.Aula;

public class AssistirVideo extends Activity {
    VideoView videoView;
    String idAula;
    Aula aula;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assistir_video);
        videoView = findViewById(R.id.videoView);
        Intent intent = getIntent();
        idAula = intent.getStringExtra("idAula");
        aula = MLiteDatabase.carregarAula(Integer.parseInt(idAula));

        final MediaController mediacontroller = new MediaController(this);
        mediacontroller.setAnchorView(videoView);


        videoView.setMediaController(mediacontroller);
        videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/raw/" + aula.getVideo()));
        videoView.requestFocus();
        videoView.start();

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                    @Override
                    public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
                        videoView.setMediaController(mediacontroller);
                        mediacontroller.setAnchorView(videoView);

                    }
                });
            }
        });

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Toast.makeText(getApplicationContext(), "Vídeo Encerrado", Toast.LENGTH_SHORT).show();
                responderQuiz();
            }
        });

    }
    private void responderQuiz(){
        Intent i = new Intent(this, Quiz.class);
        i.putExtra("idAula",aula.getId());
        startActivity(i);
        finish();
    }
}
