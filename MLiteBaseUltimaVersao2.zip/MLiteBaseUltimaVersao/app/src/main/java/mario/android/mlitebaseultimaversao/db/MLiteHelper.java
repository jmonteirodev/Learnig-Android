package mario.android.mlitebaseultimaversao.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import mario.android.mlitebaseultimaversao.pojo.*;

public class MLiteHelper extends SQLiteOpenHelper {
	
	public MLiteHelper(Context context) {
		super(context, MLiteContract.NOME_BANCO, null, MLiteContract.VERSAO);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		/**
		 * Implemente aqui a cria��o do banco de dados e a 
		 * inser��o de registros iniciais (para teste da aplica��o)
		 */
		db.execSQL(MLiteContract.TableAula.SQL_CRIAR_TABELA);
		db.execSQL(MLiteContract.TableQuiz.SQL_CRIAR_TABELA);
		db.execSQL(MLiteContract.TableQuestao.SQL_CRIAR_TABELA);
		db.execSQL(MLiteContract.TableItem.SQL_CRIAR_TABELA);
		Aula a1 = new Aula();
		a1.setId(1);
		a1.setTitulo("De onde vem a energia elétrica?");
		a1.setDescricao("Entenda quais as tecnologias envolvidas na produção de energia eletétrica.");
		a1.setVideo("me000729");
		a1.setMiniatura("ime000729");
		a1.setAcessada(false);
		db.insert("Aula", null, converterAula(a1));
		Quiz qz1 = new Quiz();
		qz1.setId(1);
		qz1.setTitulo("Vamos testar seus conhecimentos sobre energia elétrica");
		qz1.setAula(a1);
		db.insert("Quiz", null, converterQuiz(qz1));
		Questao q1 = new Questao();
		q1.setId(1);
		q1.setEnunciado("Como se chama a usina que produz energia com a força das águas?");
		q1.setQuiz(qz1);
		db.insert("Questao", null, converterQuestao(q1));

		Item i1 = new Item();
		i1.setId(1);
		i1.setDescricao("Hidroponica.");
		i1.setFeddback("Incorreto. Esse termo corresponde a uma tecnica de cultivo de vegetais sem solo.");
		i1.setCorreto(false);
		i1.setQuestao(q1);
		db.insert("Item", null, converterItem(i1));

		Item i2 = new Item();
		i2.setId(2);
		i2.setDescricao("Termoeletrica.");
		i2.setFeddback("Incorreto. Esse tipo de usina produz energia a partir da queima de combustiveis.");
		i2.setCorreto(false);
		i2.setQuestao(q1);
		db.insert("Item", null, converterItem(i2));

		Item i3 = new Item();
		i3.setId(3);
		i3.setDescricao("Nuclear.");
		i3.setFeddback("Incorreto. Esse tipo de usina utiliza elementos radioativos como o Uranio para produzir energia.");
		i3.setCorreto(false);
		i3.setQuestao(q1);
		db.insert("Item", null, converterItem(i3));

		Item i4 = new Item();
		i4.setId(4);
		i4.setDescricao("Hidroeletrica.");
		i4.setFeddback("Correto! O nome hidroeletrica vem da composicao de Hidro (agua) e Eletrica (eletricidade).");
		i4.setCorreto(true);
		i4.setQuestao(q1);
		db.insert("Item", null, converterItem(i4));


		Questao q2 = new Questao();
		q2.setId(2);
		q2.setEnunciado("Como se chama a usina que produz energia com a força das águas?");
		q2.setQuiz(qz1);
		db.insert("Questao", null, converterQuestao(q2));

		Item i5 = new Item();
		i5.setId(5);
		i5.setDescricao("Hidroponica.");
		i5.setFeddback("Incorreto. Esse termo corresponde a uma tecnica de cultivo de vegetais sem solo.");
		i5.setCorreto(false);
		i5.setQuestao(q2);
		db.insert("Item", null, converterItem(i5));

		Item i6 = new Item();
		i6.setId(6);
		i6.setDescricao("Termoeletrica.");
		i6.setFeddback("Incorreto. Esse tipo de usina produz energia a partir da queima de combustiveis.");
		i6.setCorreto(false);
		i6.setQuestao(q2);
		db.insert("Item", null, converterItem(i6));

		Item i7 = new Item();
		i7.setId(7);
		i7.setDescricao("Nuclear.");
		i7.setFeddback("Incorreto. Esse tipo de usina utiliza elementos radioativos como o Uranio para produzir energia.");
		i7.setCorreto(false);
		i7.setQuestao(q2);
		db.insert("Item", null, converterItem(i7));

		Item i8 = new Item();
		i8.setId(8);
		i8.setDescricao("Hidroeletrica.");
		i8.setFeddback("Correto! O nome hidroeletrica vem da composicao de Hidro (agua) e Eletrica (eletricidade).");
		i8.setCorreto(true);
		i8.setQuestao(q2);
		db.insert("Item", null, converterItem(i8));

	}

	public static ContentValues converterAula(Aula aula){

		ContentValues values = new ContentValues();
		values.put(MLiteContract.TableAula.COLUNA_ID, aula.getId());
		values.put(MLiteContract.TableAula.COLUNA_TITULO, aula.getTitulo());
		values.put(MLiteContract.TableAula.COLUNA_DESCRICAO, aula.getDescricao());
		values.put(MLiteContract.TableAula.COLUNA_VIDEO, aula.getVideo());
		values.put(MLiteContract.TableAula.COLUNA_MINIATURA, aula.getMiniatura());
		values.put(MLiteContract.TableAula.COLUNA_ACESSADA, aula.getAcessada());

		return values;
	}
	public static ContentValues converterQuiz(Quiz quiz){

		ContentValues values = new ContentValues();
		values.put(MLiteContract.TableQuiz.COLUNA_ID, quiz.getId());
		values.put(MLiteContract.TableQuiz.COLUNA_TITULO, quiz.getTitulo());
		values.put(MLiteContract.TableQuiz.COLUNA_AULA, quiz.getAula().getId());

		return values;
	}

	public static ContentValues converterQuestao(Questao questao){

		ContentValues values = new ContentValues();
		values.put(MLiteContract.TableQuestao.COLUNA_ID, questao.getId());
		values.put(MLiteContract.TableQuestao.COLUNA_ENUNCIADO, questao.getEnunciado());
		values.put(MLiteContract.TableQuestao.COLUNA_QUIZ, questao.getQuiz().getId());

		return values;
	}

	public static ContentValues converterItem(Item item){

		ContentValues values = new ContentValues();
		values.put(MLiteContract.TableItem.COLUNA_ID, item.getId());
		values.put(MLiteContract.TableItem.COLUNA_DESCRICAO, item.getDescricao());
		values.put(MLiteContract.TableItem.COLUNA_FEEDBACK, item.getFeddback());
		values.put(MLiteContract.TableItem.COLUNA_CORRETO, item.getCorreto());
		values.put(MLiteContract.TableItem.COLUNA_QUESTAO, item.getQuestao().getId());

		return values;
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		db.execSQL("DROP TABLE IF EXISTS " + MLiteContract.TableAula.NOME_TABELA);
		db.execSQL("DROP TABLE IF EXISTS " + MLiteContract.TableQuiz.NOME_TABELA);
		db.execSQL("DROP TABLE IF EXISTS " + MLiteContract.TableQuestao.NOME_TABELA);
		db.execSQL("DROP TABLE IF EXISTS " + MLiteContract.TableItem.NOME_TABELA);
	}

}
