package mario.android.mlitebaseultimaversao.activity;

import android.app.Activity;
import android.os.Bundle;

import mario.android.mlitebaseultimaversao.R;

public class ResultadoQuiz extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_quiz);
    }
}
