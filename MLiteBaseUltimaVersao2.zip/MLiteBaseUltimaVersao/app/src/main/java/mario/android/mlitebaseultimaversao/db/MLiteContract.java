package mario.android.mlitebaseultimaversao.db;


import android.provider.BaseColumns;

public class MLiteContract {

	public static final String NOME_BANCO = "mlite.db";
	public static final int VERSAO = 1;

	/**
	 * Defina nessa classe a estrutura das tabelas do banco de
	 * dados da aplica��o. Voc� pode fazer modifica��es no que
	 * foi sugerido em aula ou usado na classes do pacote 
	 * android.mlite.pojo, contanto que não deixe de cumprir os
	 * requisitos do projeto.
	 */
	public static abstract class TableAula implements BaseColumns {
		public static final String NOME_TABELA = "Aula";
		public static final String COLUNA_ID = "id";
		public static final String COLUNA_TITULO = "titulo";
		public static final String COLUNA_DESCRICAO = "descricao";
		public static final String COLUNA_VIDEO = "video";
		public static final String COLUNA_MINIATURA = "miniatura";
		public static final String COLUNA_ACESSADA = "acessada";

		public static final String SQL_CRIAR_TABELA = "CREATE TABLE "+ NOME_TABELA + "("+
				TableAula.COLUNA_ID + " INTEGER PRIMARY KEY,"+
				TableAula.COLUNA_TITULO + " TEXT, "+
				TableAula.COLUNA_DESCRICAO + " TEXT, "+
				TableAula.COLUNA_VIDEO + " TEXT, "+
				TableAula.COLUNA_ACESSADA + " BOOLEAN, "+
				TableAula.COLUNA_MINIATURA + " TEXT "+ ")";

	}
	public static abstract class TableQuiz implements BaseColumns{
		public static final String NOME_TABELA = "Quiz";
		public static final String COLUNA_ID = "id";
		public static final String COLUNA_AULA = "aula";
		public static final String COLUNA_TITULO = "titulo";

		public static final String SQL_CRIAR_TABELA = "CREATE TABLE "+ NOME_TABELA + "("+
				TableQuiz.COLUNA_ID + " INTEGER PRIMARY KEY,"+
				TableQuiz.COLUNA_AULA + " TEXT, "+
				TableQuiz.COLUNA_TITULO + " TEXT "+ ")";
	}
	public static abstract class TableItem implements BaseColumns{
		public static final String NOME_TABELA = "Item";
		public static final String COLUNA_ID = "id";
		public static final String COLUNA_FEEDBACK = "feddback";
		public static final String COLUNA_DESCRICAO = "descricao";
		public static final String COLUNA_CORRETO = "correto";
		public static final String COLUNA_QUESTAO = "questao";

		public static final String SQL_CRIAR_TABELA = "CREATE TABLE "+ NOME_TABELA + "("+
				TableItem.COLUNA_ID + " INTEGER PRIMARY KEY,"+
				TableItem.COLUNA_FEEDBACK + " TEXT, "+
				TableItem.COLUNA_DESCRICAO + " TEXT, "+
				TableItem.COLUNA_QUESTAO + " TEXT, "+
				TableItem.COLUNA_CORRETO + " BOOLEAN "+")";
	}
	public static abstract class TableQuestao implements BaseColumns{
		public static final String NOME_TABELA = "Questao";
		public static final String COLUNA_ID = "id";
		public static final String COLUNA_ENUNCIADO = "enunciado";
		public static final String COLUNA_QUIZ = "quiz";

		public static final String SQL_CRIAR_TABELA = "CREATE TABLE "+ NOME_TABELA + "("+
				TableQuestao.COLUNA_ID + " INTEGER PRIMARY KEY,"+
				TableQuestao.COLUNA_QUIZ + " TEXT "+
				TableQuestao.COLUNA_ENUNCIADO + " TEXT "+")";
	}
}
