package mario.android.mlitebaseultimaversao.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import mario.android.mlitebaseultimaversao.pojo.*;


public class MLiteDatabase {

	private static MLiteHelper helper;
	private static SQLiteDatabase db;

	public static void inicializar(Context contexto) {
		if (helper == null) {
			helper = new MLiteHelper(contexto);
		}
	}

	public static void encerrarSessao() {
		if (db != null)
			db.close();
	}

	/**
	 * Monta a lista completa de aulas do banco de dados.
	 * @return uma lista contendo todas as aulas do banco de dados.
	 */
	public static List<Aula> carregarAulas() {
		List<Aula> aulas = new ArrayList<Aula>();
		StringBuilder sql = new StringBuilder();

		//sql.append("SELECT CODIGO,NOME,ENDERECO,EMAIL,TELEFONE ");
		//sql.append("FROM CLIENTES");
		//String[] campos =  {MLiteContract.TableAula._ID,MLiteContract.TableAula.COLUNA_TITULO,MLiteContract.TableAula.COLUNA_DESCRICAO,MLiteContract.TableAula.COLUNA_VIDEO,MLiteContract.TableAula.COLUNA_MINIATURA,MLiteContract.TableAula.COLUNA_ACESSADA};

		db = helper.getReadableDatabase();
		//Cursor resultado = db.query(MLiteContract.TableAula.NOME_TABELA, campos, null, null, null, null, null, null);
		sql.append("SELECT id,titulo,descricao,video,miniatura, acessada ");
		sql.append("FROM Aula");
		Cursor resultado = db.rawQuery(sql.toString(), null);
		try {

			if (resultado.getCount() > 0) {

				resultado.moveToFirst();

				do {
					Aula aula = new Aula();

					aula.setId(resultado.getInt(resultado.getColumnIndexOrThrow("id")));
					aula.setTitulo(resultado.getString(resultado.getColumnIndexOrThrow("titulo")));
					aula.setDescricao(resultado.getString(resultado.getColumnIndexOrThrow("descricao")));
					aula.setVideo(resultado.getString(resultado.getColumnIndexOrThrow("video")));
					aula.setMiniatura(resultado.getString(resultado.getColumnIndexOrThrow("miniatura")));
					aula.setAcessada(Boolean.valueOf(resultado.getString(resultado.getColumnIndexOrThrow("acessada"))));
					aulas.add(aula);

				} while (resultado.moveToNext());


			}
		}catch(SQLException ex){

		}

		return aulas;
		//return MLiteDatabaseMock.carregarAulas();

	}

	/**
	 * Monta a representa??o de uma aula espec?fica a partir de seu identificador.
	 * @param idAula identificador da aula
	 * @return Aula
	 */
	public static Aula carregarAula(Integer idAula) {
		Aula aula = new Aula();
		StringBuilder sql = new StringBuilder();

		//sql.append("SELECT CODIGO,NOME,ENDERECO,EMAIL,TELEFONE ");
		//sql.append("FROM CLIENTES");
		//String[] campos =  {MLiteContract.TableAula._ID,MLiteContract.TableAula.COLUNA_TITULO,MLiteContract.TableAula.COLUNA_DESCRICAO,MLiteContract.TableAula.COLUNA_VIDEO,MLiteContract.TableAula.COLUNA_MINIATURA,MLiteContract.TableAula.COLUNA_ACESSADA};

		db = helper.getReadableDatabase();
		//Cursor resultado = db.query(MLiteContract.TableAula.NOME_TABELA, campos, null, null, null, null, null, null);
		sql.append("SELECT id,titulo,descricao,video,miniatura, acessada ");
		sql.append("FROM Aula WHERE id ="+idAula);
		Cursor resultado = db.rawQuery(sql.toString(), null);
		try {

			if (resultado.getCount() > 0) {

				resultado.moveToFirst();

				do {
					aula.setId(resultado.getInt(resultado.getColumnIndexOrThrow("id")));
					aula.setTitulo(resultado.getString(resultado.getColumnIndexOrThrow("titulo")));
					aula.setDescricao(resultado.getString(resultado.getColumnIndexOrThrow("descricao")));
					aula.setVideo(resultado.getString(resultado.getColumnIndexOrThrow("video")));
					aula.setMiniatura(resultado.getString(resultado.getColumnIndexOrThrow("miniatura")));
					aula.setAcessada(Boolean.valueOf(resultado.getString(resultado.getColumnIndexOrThrow("acessada"))));
				} while (resultado.moveToNext());


			}
		}catch(SQLException ex){

		}

		return aula;
		//return MLiteDatabaseMock.carregarAula(idAula);

	}

	/**
	 * Obt?m o quiz de uma aula indicada.
	 * @param idAula identificador da aula
	 * @return O Quiz da aula indicada
	 */
	public static Quiz carregarQuiz(Integer idAula) {
		Quiz quiz = new Quiz();
		StringBuilder sql = new StringBuilder();

		//sql.append("SELECT CODIGO,NOME,ENDERECO,EMAIL,TELEFONE ");
		//sql.append("FROM CLIENTES");
		//String[] campos =  {MLiteContract.TableAula._ID,MLiteContract.TableAula.COLUNA_TITULO,MLiteContract.TableAula.COLUNA_DESCRICAO,MLiteContract.TableAula.COLUNA_VIDEO,MLiteContract.TableAula.COLUNA_MINIATURA,MLiteContract.TableAula.COLUNA_ACESSADA};

		db = helper.getReadableDatabase();
		//Cursor resultado = db.query(MLiteContract.TableAula.NOME_TABELA, campos, null, null, null, null, null, null);
		sql.append("SELECT id,titulo ");
		sql.append("FROM Quiz WHERE aula ="+idAula);
		Cursor resultado = db.rawQuery(sql.toString(), null);
		try {

			if (resultado.getCount() > 0) {

				resultado.moveToFirst();

				do {

					quiz.setId(resultado.getInt(resultado.getColumnIndexOrThrow("id")));
					quiz.setTitulo(resultado.getString(resultado.getColumnIndexOrThrow("titulo")));
					quiz.setQuestoes(carregarQuestoes(quiz.getId()));

				} while (resultado.moveToNext());


			}
		}catch(SQLException ex){

		}

		return quiz;
		//return MLiteDatabaseMock.carregarQuiz(idAula);

	}

	public static List<Questao> carregarQuestoes(Integer idQuiz) {
		List<Questao> questaoList = new ArrayList<Questao>();
		StringBuilder sql = new StringBuilder();
		db = helper.getReadableDatabase();
		sql.append("SELECT id,enunciado ");
		sql.append("FROM Questao WHERE quiz ="+idQuiz);
		Cursor resultado = db.rawQuery(sql.toString(), null);
		try {

			if (resultado.getCount() > 0) {

				resultado.moveToFirst();

				do {
					Questao questao = new Questao();

					questao.setId(resultado.getInt(resultado.getColumnIndexOrThrow("id")));
					questao.setEnunciado(resultado.getString(resultado.getColumnIndexOrThrow("enunciado")));
					questao.setItens(carregarItens(questao.getId()));
					questaoList.add(questao);

				} while (resultado.moveToNext());


			}
		}catch(SQLException ex){

		}

		return questaoList;
		//return MLiteDatabaseMock.carregarQuiz(idAula);

	}

	public static List<Item> carregarItens(Integer idQuestao) {
		List<Item> itemList = new ArrayList<Item>();
		StringBuilder sql = new StringBuilder();
		db = helper.getReadableDatabase();
		sql.append("SELECT id,descricao, feedback, correto ");
		sql.append("FROM Item WHERE questao ="+idQuestao);
		Cursor resultado = db.rawQuery(sql.toString(), null);
		try {

			if (resultado.getCount() > 0) {

				resultado.moveToFirst();

				do {
					Item item = new Item();

					item.setId(resultado.getInt(resultado.getColumnIndexOrThrow("id")));
					item.setDescricao(resultado.getString(resultado.getColumnIndexOrThrow("descricao")));
					item.setFeddback(resultado.getString(resultado.getColumnIndexOrThrow("feedback")));
					item.setCorreto(Boolean.valueOf(resultado.getString(resultado.getColumnIndexOrThrow("correto"))));
					itemList.add(item);

				} while (resultado.moveToNext());


			}
		}catch(SQLException ex){

		}

		return itemList;
		//return MLiteDatabaseMock.carregarQuiz(idAula);

	}
	/**
	 * Este m?todo deve ser implementado para marcar uma aula como "acessada".
	 * O c?lculo do progresso do usu?rio ? baseado na divis?o da quantidade de aulas
	 * acessadas pelo n?mero total de quest?es do banco de dados.
	 * @param idAula identificador da aula
	 */
	public static void marcarAulaAcessadas(String idAula) {
		ContentValues contentValues = new ContentValues();

		contentValues.put("acessada",true);

		String[] parametros = new String[1];

		parametros[0] = String.valueOf(idAula);

		db.update("Aula",contentValues,"id=?",parametros);

	}

	public String inserir(String table, ContentValues valores){

		db = helper.getWritableDatabase();

		long resultado = db.insert(table, null, valores);
		db.close();

		if (resultado == -1)
			return "Erro ao inserir registro";
		else
			return "Registro Inserido com sucesso";
	}
}
