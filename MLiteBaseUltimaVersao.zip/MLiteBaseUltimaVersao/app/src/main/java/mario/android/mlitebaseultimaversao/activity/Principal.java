package mario.android.mlitebaseultimaversao.activity;

import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.List;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;

import android.net.Uri;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import mario.android.mlitebaseultimaversao.R;
import mario.android.mlitebaseultimaversao.db.MLiteDatabase;
import mario.android.mlitebaseultimaversao.db.MLiteDatabaseMock;
import mario.android.mlitebaseultimaversao.pojo.Aula;
import mario.android.mlitebaseultimaversao.util.Util;

public class Principal extends Activity {

	private SharedPreferences sp;

	// Valor do progresso do Usuário em termos de aulas assistidas
	private float progresso;

	// layout que armazena as aulas
	private LinearLayout containerAulas;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_principal);
		
		// Inicializa��o do Mock
		MLiteDatabaseMock.inicializar();

		// Inicializando o objeto de Prefer�ncias Compartilhadas
		sp = getSharedPreferences(Util.SP_PERFIL_USUARIO, MODE_PRIVATE);

		// Montagem do painel de informa��es do Usuário
		montarDadosUsuario();

		// Montagem da lista de aula na tela com acesso ass�ncrona ao BD
		containerAulas = (LinearLayout) findViewById(R.id.ll_lista_aulas);
		new CarregarAulasTask().execute();
	}

	/**
	 * Exibe os dados de perfil do Usuário na tela principal.
	 */
	private void montarDadosUsuario() {

		// Resgate do nome do Usuário das Prefer�ncias Compartilhadas
		TextView nomeUsuario = (TextView) findViewById(R.id.tv_nome_usuario);
		nomeUsuario.setText(sp.getString(Util.SP_PERFIL_NOME_USUARIO,
				Util.SP_PERFIL_NOME_USUARIO_PADRAO));

		// Resgate da foto do Usuário das Prefer�ncias Compartilhadas
		String uriImagemUsuarioStr = sp
				.getString(Util.SP_PERFIL_URI_IMAGEM, "");
		try {
			if (!uriImagemUsuarioStr.isEmpty()) {
				ImageView fotoUsuario = (ImageView) findViewById(R.id.iv_usuario);
				Bitmap imagemUsuario = Util.decodeUri(getContentResolver(),
						Uri.parse(uriImagemUsuarioStr));
				fotoUsuario.setImageBitmap(imagemUsuario);
			}
		} catch (FileNotFoundException fnfe) {
			Toast.makeText(getApplicationContext(),
					Util.MSG_ARQUIVO_NAO_ENCONTRADO, Toast.LENGTH_LONG).show();
			Log.e(Util.TAG_ERRO, Util.MSG_ARQUIVO_NAO_ENCONTRADO);
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), Util.MSG_EXCECAO,
					Toast.LENGTH_LONG).show();
			String contexto = "Retorno da sele��o de imagem para perfil.\n";
			Log.e(Util.TAG_ERRO, contexto + e.getMessage());
		}

	}

	/**
	 * Exibe a lista de aulas dispon�veis na aplica��o. O preenchimento do
	 * objeto 'listaAulas' � feito de forma ass�ncrona durante o acesso ao banco
	 * de dados pela classe {@code CarregarAulasTask}. Tamb�m � feito o c�lculo
	 * do progresso do aluno (aulas assistidas / aulas totais).
	 */
	public void montarListaAulas(List<Aula> listaAulas) {
		// Verificando o preenchimento da lista de aulas
		if (listaAulas != null && listaAulas.size() > 0) {

			// Inflater - para aloca��o din�mica de componentes na UI
			LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			float aulasAcessadas = 0f;
			
			// Itera��o na lista de aulas
			for (Aula aula : listaAulas) {

				if(aula.getAcessada())
					aulasAcessadas++;
				
				// Instancia��o do LinearLayout base da aula
				LinearLayout linhaAula = (LinearLayout) inflater.inflate(
						R.layout.item_aula, containerAulas, false);

				// �cone da aula (Miniatura do V�deo)
				ImageView icone = (ImageView) linhaAula
						.findViewById(R.id.iv_miniatura_aula);

				/**
				 * Definindo o ContentDescription como ID da aula para captura
				 * no evento de clique.
				 */
				icone.setContentDescription(aula.getId().toString());

				int miniatura = getResources().getIdentifier(aula.getMiniatura(), 
						"drawable",	getPackageName());
				if (miniatura != 0)
					icone.setImageResource(miniatura);
				icone.setAlpha(aula.getAcessada() ? Util.TRANSPARENTE_30
						: Util.TRANSPARENTE_0);

				// T�tulo da aula
				TextView titulo = (TextView) linhaAula
						.findViewById(R.id.tv_titulo_aula);
				titulo.setText(aula.getTitulo());

				// Descri��o da aula
				TextView descricao = (TextView) linhaAula
						.findViewById(R.id.tv_descricao_aula);
				descricao.setText(aula.getDescricao());

				// Adi��o do layout de aula � lista em tela
				containerAulas.addView(linhaAula);
			}
			
			// Exibi��o do progresso do Usuário por extenso e em barra
			progresso = aulasAcessadas / listaAulas.size();

			DecimalFormat df = new DecimalFormat("#0");
			TextView progessoTexto = (TextView) findViewById(R.id.tv_progresso_usuario);
			progessoTexto.setText("Progresso: " + df.format(progresso * 100)
					+ "%");

			ProgressBar progessoBarra = (ProgressBar) findViewById(R.id.pb_progresso_usuario);
			progessoBarra.setProgress((int) (progresso * 100));

		}
	}

	/**
	 * Dispara a navega��o para o v�deo da aula selecionada
	 * @param v refer�ncia ao item da lista de aulas clicado
	 */
	public void abrirVideoAula(View v) {
		/* TODO: Implementar este m�todo de navega��o para 
		 * a activity de Assistir Aula */
		Toast.makeText(getApplicationContext(), 
				R.string.msg_activity_video_pendente, Toast.LENGTH_LONG).show();
	}

	@Override
	public void onBackPressed() {
		finish();
	}

	/**
	 * Tarefa ass�ncrona para carregamento da lista de aulas que
	 * fica na tela principal da aplica��o. Os dados das aulas est�o
	 * no Banco de Dados.
	 */
	private class CarregarAulasTask extends AsyncTask<Void, Void, List<Aula>> {

		protected void onPreExecute() {
			MLiteDatabase.inicializar(getApplicationContext());
		}

		@Override
		protected List<Aula> doInBackground(Void... param) {
			// carregamento da lista de aulas
			return MLiteDatabase.carregarAulas();
		}

		@Override
		protected void onPostExecute(List<Aula> aulas) {
			montarListaAulas(aulas);
		}
	}

}
