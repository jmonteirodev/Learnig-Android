package mario.android.mlitebaseultimaversao.pojo;

import java.util.ArrayList;
import java.util.List;

public class Aula {
	
	private Integer id;
	private String titulo;
	private String descricao;
	private String video;
	private String miniatura;
	private Boolean acessada;
	
	private List<Quiz> quizzes;
	
	public Aula() {
		quizzes = new ArrayList<Quiz>();
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Boolean getAcessada() {
		return acessada;
	}
	public void setAcessada(Boolean acessada) {
		this.acessada = acessada;
	}
	
	public List<Quiz> getQuizzes() {
		return quizzes;
	}
	
	public void setQuizzes(List<Quiz> quizzes) {
		this.quizzes = quizzes;
	}
	
	public void adicionarQuiz(Quiz quiz) {
		if (quizzes != null)
			quizzes.add(quiz);
	}
	
	public String getVideo() {
		return video;
	}
	
	public void setVideo(String video) {
		this.video = video;
	}
	
	public String getMiniatura() {
		return miniatura;
	}
	public void setMiniatura(String miniatura) {
		this.miniatura = miniatura;
	}
	
}
