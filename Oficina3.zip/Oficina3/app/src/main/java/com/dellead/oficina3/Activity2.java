package com.dellead.oficina3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Random;

public class Activity2 extends AppCompatActivity {
    TextView selecionado;
    TextView resultado;
    TextView resulta;
    private enum CaraOuCoroa {
        Cara,
        Coroa;

        /**
         * Pick a random value of the BaseColor enum.
         * @return a random BaseColor.
         */
        public static CaraOuCoroa getResult() {
            Random random = new Random();
            return values()[random.nextInt(values().length)];
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        selecionado = (TextView) findViewById(R.id.selecionado);
        resultado = (TextView) findViewById(R.id.resultado);
        resulta = (TextView) findViewById(R.id.result);
        Intent it = getIntent();
        String select = it.getStringExtra("selecionado");
        selecionado.setText(select);
        CaraOuCoroa result = CaraOuCoroa.getResult();
        resultado.setText(resultado.getText().toString()+" - "+result.toString());
        if(result.toString().equals(select.toString()))
            resulta.setText("Vitória");
        else
            resulta.setText("Derrota");
    }
}
