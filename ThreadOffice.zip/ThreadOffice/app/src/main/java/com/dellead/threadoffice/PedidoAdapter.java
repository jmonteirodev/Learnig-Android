package com.dellead.threadoffice;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PedidoAdapter extends RecyclerView.Adapter<PedidoAdapter.ViewHolderPedido> {
    private List<Pedido> pedidos;
    public PedidoAdapter(List<Pedido> pedido){
        this.pedidos = pedido;
    }
    @Override
    public PedidoAdapter.ViewHolderPedido onCreateViewHolder(ViewGroup parent, int viewType) {


        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item,parent,false);

        ViewHolderPedido holderPedido = new ViewHolderPedido(view);
        return holderPedido;

    }
    @Override
    public void onBindViewHolder(PedidoAdapter.ViewHolderPedido holder, int position) {
        if((pedidos != null) && (pedidos.size()>0)){

            Pedido pedido = pedidos.get(position);
            holder.textNome.setText(pedidos.get(position).getName());


        }
    }
    public int getItemCount(){
        return pedidos.size();
    }

    public class ViewHolderPedido extends RecyclerView.ViewHolder {
        public TextView textNome;
        public TextView textValor;

        public ViewHolderPedido(View itemView){
            super(itemView);
            textNome = (TextView) itemView.findViewById(R.id.tvNome);

        }
    }
}
