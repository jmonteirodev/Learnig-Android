package com.dellead.threadoffice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private RecyclerView lst_dados;
    private ConstraintLayout layoutContentMain;
    private List<Pedido> dados;
    private PedidoAdapter pedidoAdapter;
    Button atualizar;
    Button limpar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lst_dados = (RecyclerView)findViewById(R.id.lst_peds);
        dados = new ArrayList<Pedido>();
        layoutContentMain = (ConstraintLayout)findViewById(R.id.layoutContentMain);
        lst_dados.setHasFixedSize(true);

        LinearLayoutManager linerLayoutManager = new LinearLayoutManager(this);
        lst_dados.setLayoutManager(linerLayoutManager);
        dados = new ArrayList<Pedido>();

        atualizar = (Button)findViewById(R.id.button);
        atualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AsyncTaskRunner runner = new AsyncTaskRunner();
                String tempoAguardo = "2";
                runner.execute(tempoAguardo);
            }
        });
        limpar = (Button)findViewById(R.id.button2);
        limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dados = new ArrayList<Pedido>();
                pedidoAdapter = new PedidoAdapter(dados);
                lst_dados.setAdapter(pedidoAdapter);
            }
        });
    }
    private class AsyncTaskRunner extends AsyncTask<String, String, String> {
        private String resp;
        @Override
        protected String doInBackground(String... params) {
            try {
                Random random = new Random();
                int randomNumber = random.nextInt(10)+1;
                Thread.sleep(randomNumber*2000);
                resp = String.valueOf(randomNumber);
            } catch (InterruptedException e) {
                e.printStackTrace();
                resp = String.valueOf(0);
            } catch (Exception e) {
                e.printStackTrace();
                resp = String.valueOf(0);
            }
            return resp;
        }
        @Override
        protected void onPostExecute(String result) {
            Random random = new Random();
            dados = new ArrayList<Pedido>();
            for(int i = 1; i <= Integer.parseInt(result); i++) {
                Pedido pd = new Pedido();
                pd.setName("Pedido "+i+": R$"+(random.nextInt(1000-800)+800)+".00");
                dados.add(pd);
            }
            pedidoAdapter = new PedidoAdapter(dados);
            lst_dados.setAdapter(pedidoAdapter);
        }
    }
}
