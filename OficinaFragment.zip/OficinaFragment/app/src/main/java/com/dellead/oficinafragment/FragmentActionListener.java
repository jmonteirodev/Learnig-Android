package com.dellead.oficinafragment;

public interface FragmentActionListener {

    String KEY_SELECTED_NAME="KEY_SELECTED_NAME";

    void onNameSelected(String name);
}
