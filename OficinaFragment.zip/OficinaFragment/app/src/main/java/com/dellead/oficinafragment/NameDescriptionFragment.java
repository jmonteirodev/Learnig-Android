package com.dellead.oficinafragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class NameDescriptionFragment extends Fragment {
    View rootView;
    TextView textView;

    String name;
    String description;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_fragment2, container, false);
        initUI();
        return rootView;
    }

    private void initUI(){
        textView = (TextView)rootView.findViewById(R.id.textView);
    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(name);
        textView.setText(description);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i("OrintationChange","NameDescriptionFragment onSaveInstanceState");
        //outState.putString("selectedName",name);
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        Bundle bundle = getArguments();
        name = bundle.getString(FragmentActionListener.KEY_SELECTED_NAME,"Maria");
        description = (String) getResources().getText(getResources().getIdentifier(name, "string","com.dellead.oficinafragment"));
    }
}
