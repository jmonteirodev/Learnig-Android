package com.dellead.officelocation;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener {
    private LocationManager locationManager;
    private TextView lat;
    private TextView log;
    private TextView vel;
    Sensor mAcelerometro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lat = (TextView) findViewById(R.id.lat);
        log = (TextView) findViewById(R.id.log);
        vel = (TextView) findViewById(R.id.velo);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }else {
            SensorManager mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            mAcelerometro = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
            mSensorManager.registerListener(new SppedSensor(), mAcelerometro,
                    SensorManager.SENSOR_DELAY_UI);
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        locationManager.removeUpdates(this);
    }
    public void onLocationChanged(Location location) {
        getLocalizacao(location);
    }
    public void getLocalizacao(Location location){
        lat.setText(String.valueOf(location.getLatitude()));
        log.setText(String.valueOf(location.getLongitude()));
    }
    public void getVelocidade(SensorEvent event){
        vel.setText(String.valueOf(event.values[0]));
    }
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Toast.makeText(this, "aaa bom " , Toast.LENGTH_SHORT).show();

    }


    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Provider Desabilitado " + provider, Toast.LENGTH_SHORT).show();
        startActivityForResult(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS), 0);
    }

    @Override
    public void onProviderEnabled(String provider) {
        Toast.makeText(this, "Provider Hbilitado " + provider, Toast.LENGTH_SHORT).show();
    }
    class SppedSensor implements SensorEventListener {
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }

        public void onSensorChanged(SensorEvent event) {
            getVelocidade(event);
        }
    }
}
