package com.dellead.cicloactivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;



public class CicloLogActivity extends Activity {
    private static final String FILTRO = "Ciclo";
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(FILTRO, "Metodo onCreate chamado!");
    }

    /** Chamado quando a Activity está prestes a se tornar visível. */
    @Override
    protected void onStart() {
        super.onStart();
        Log.i(FILTRO, "Metodo onStart chamado!");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(FILTRO, "Metodo onResume chamado!");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(FILTRO, "Metodo onPause chamado!");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(FILTRO, "Metodo onStop chamado!");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(FILTRO, "Metodo onDestroy chamado!");
    }
}
