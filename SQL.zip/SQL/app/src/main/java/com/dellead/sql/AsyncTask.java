package com.dellead.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class AsyncTask {
    private SQLiteDatabase db;
    private BancoHelper banco;
    public AsyncTask(Context context){
        banco = new BancoHelper(context);
    }
    public String inserir(ContentValues valores){

        db = banco.getWritableDatabase();

        long resultado = db.insert(ContratoBanco.TabelaTime.NOME_TABELA, null, valores);
        db.close();

        if (resultado == -1)
            return "Erro ao inserir registro";
        else
            return "Registro Inserido com sucesso";
    }

    public Cursor carregaDados(){
        Cursor cursor;
        String[] campos =  {ContratoBanco.TabelaTime._ID,ContratoBanco.TabelaTime.COLUNA_NOME_ESPORTE,ContratoBanco.TabelaTime.COLUNA_NOME_TIME, ContratoBanco.TabelaTime.COLUNA_NOME_EQUIPE, ContratoBanco.TabelaTime.COLUNA_NOME_JOGADORES};

        db = banco.getReadableDatabase();
        cursor = db.query(ContratoBanco.TabelaTime.NOME_TABELA, campos, null, null, null, null, null, null);

        if(cursor!=null){
            cursor.moveToFirst();
        }
        db.close();
        return cursor;
    }
}