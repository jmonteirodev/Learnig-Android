package com.dellead.sql;

public class Equipe {
    private int id;
    private String nomeEsporte;
    private String nomeTime;
    private String nomeEquipe;
    private String nomeJogadores;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeEsporte() {
        return nomeEsporte;
    }

    public void setNomeEsporte(String nomeEsporte) {
        this.nomeEsporte = nomeEsporte;
    }

    public String getNomeTime() {
        return nomeTime;
    }

    public void setNomeTime(String nomeTime) {
        this.nomeTime = nomeTime;
    }

    public String getNomeEquipe() {
        return nomeEquipe;
    }

    public void setNomeEquipe(String nomeEquipe) {
        this.nomeEquipe = nomeEquipe;
    }

    public String getNomeJogadores() {
        return nomeJogadores;
    }

    public void setNomeJogadores(String nomeJogadores) {
        this.nomeJogadores = nomeJogadores;
    }
}
