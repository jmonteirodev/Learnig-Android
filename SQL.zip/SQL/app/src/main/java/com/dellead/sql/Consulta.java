package com.dellead.sql;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class Consulta extends AppCompatActivity {
    ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta);
        AsyncTask crud = new AsyncTask(getBaseContext());
        Cursor cursor = crud.carregaDados();

        String[] campos =  {ContratoBanco.TabelaTime._ID,ContratoBanco.TabelaTime.COLUNA_NOME_ESPORTE,ContratoBanco.TabelaTime.COLUNA_NOME_TIME, ContratoBanco.TabelaTime.COLUNA_NOME_EQUIPE, ContratoBanco.TabelaTime.COLUNA_NOME_JOGADORES};
        int[] idViews = new int[] {R.id.idTime,R.id.nomeEsporte, R.id.nomeTime, R.id.nomeEquipe, R.id.nomeJogadores};

        SimpleCursorAdapter adaptador = new SimpleCursorAdapter(getBaseContext(),
                R.layout.results,cursor,campos,idViews, 0);
        lista = (ListView)findViewById(R.id.listView);
        lista.setAdapter(adaptador);
    }
}
