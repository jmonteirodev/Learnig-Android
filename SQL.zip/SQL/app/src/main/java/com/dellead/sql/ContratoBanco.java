package com.dellead.sql;

import android.provider.BaseColumns;

public class ContratoBanco {
    public static final String NOME_BANCO = "atividade7.db";
    public static final int VERSAO_BANCO = 1;

    public static abstract class TabelaTime implements BaseColumns{
        public static final String NOME_TABELA = "informacoesEquipe";
        public static final String COLUNA_NOME_ESPORTE= "nomeEsporte";
        public static final String COLUNA_NOME_TIME= "nomeTime";
        public static final String COLUNA_NOME_EQUIPE= "nomeEquipe";
        public static final String COLUNA_NOME_JOGADORES= "nomeJogadores";

        public static final String SQL_CRIAR_TABELA = "CREATE TABLE "+ NOME_TABELA + "("+
                TabelaTime._ID + " INTEGER PRIMARY KEY,"+
                TabelaTime.COLUNA_NOME_ESPORTE + " TEXT, "+
                TabelaTime.COLUNA_NOME_TIME + " TEXT, "+
                TabelaTime.COLUNA_NOME_EQUIPE + " TEXT, "+
                TabelaTime.COLUNA_NOME_JOGADORES + " TEXT "+ ")";
    }
}
